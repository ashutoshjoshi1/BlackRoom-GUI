from app import SpectroApp

if __name__ == '__main__':
    app = SpectroApp()
    app.mainloop()
